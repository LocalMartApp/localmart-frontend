import React from 'react';
import PropTypes from 'prop-types';
import './MyBusiness.scss';

const MyBusiness = () => {
  return (
    <div className="MyBusiness">
      MyBusiness Component
    </div>
  );
}

MyBusiness.propTypes = {};

MyBusiness.defaultProps = {};

export default MyBusiness;
