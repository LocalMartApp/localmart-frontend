import React from 'react';
import PropTypes from 'prop-types';
import './MyFavourites.scss';

const MyFavourites = () =>{
  return  (
    <div className="MyFavourites">
      MyFavourites Component
    </div>
  );
}

MyFavourites.propTypes = {};

MyFavourites.defaultProps = {};

export default MyFavourites;
