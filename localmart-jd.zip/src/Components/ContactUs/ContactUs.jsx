import React from 'react';
import PropTypes from 'prop-types';
import './ContactUs.scss';

const ContactUs = () => {
  return (
    <div className="ContactUs">
      ContactUs Component
    </div>
  );
}

ContactUs.propTypes = {};

ContactUs.defaultProps = {};

export default ContactUs;
