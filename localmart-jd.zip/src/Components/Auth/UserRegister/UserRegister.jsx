import React from 'react';
import PropTypes from 'prop-types';
import './UserRegister.scss';

const UserRegister = () => {
  return (
    <div className="UserRegister">
      UserRegister Component
    </div>
  );
}

UserRegister.propTypes = {};

UserRegister.defaultProps = {};

export default UserRegister;
