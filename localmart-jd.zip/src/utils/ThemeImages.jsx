export const ThemeImages = {
    sliderImage1: '../assets/images/slider-image-1.jpg',
    sliderImage2: '../assets/images/slider-image-2.jpg',
    sliderImage3: '../assets/images/slider-image-3.jpg',
}


